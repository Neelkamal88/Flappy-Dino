let canvas = document.getElementById('gameCanvas');
let ctx = canvas.getContext('2d');
let bird = { x: 100, y: 150, width: 40, height: 40, velocity: 0, gravity: 0.5, flap: -8 };
let gameStarted = false;
let touchStart = false;

function resizeCanvas() {
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
}
resizeCanvas();
window.addEventListener('resize', resizeCanvas);

canvas.addEventListener('touchstart', (e) => {
    e.preventDefault();
    if (!gameStarted) {
        gameStarted = true;
        document.getElementById('startBtn').style.display = 'none';
        return;
    }
    touchStart = true;
});

canvas.addEventListener('touchend', () => {
    touchStart = false;
});

function updateGame() {
    if (touchStart) {
        bird.velocity = bird.flap;
    }
    bird.velocity += bird.gravity;
    bird.y += bird.velocity;

    ctx.fillStyle = '#87ceeb';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    ctx.fillStyle = '#ff0000';
    ctx.fillRect(bird.x, bird.y, bird.width, bird.height);

    if (bird.y + bird.height > canvas.height - 10) {
        bird.y = canvas.height - bird.height - 10;
    }
    if (bird.y < 0) bird.y = 0;

    requestAnimationFrame(updateGame);
}
document.getElementById('startBtn').addEventListener('click', () => {
    gameStarted = true;
    updateGame();
});
